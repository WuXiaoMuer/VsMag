using System;
namespace HelloWorldApplication
{
	/* 类名 HelloWorld */
	class HelloWorld
	{
		/* main主函数 */
		static void Main(string[] args)
		{
			/* 打印和暂停函数 */
			Console.WriteLine("Hello World!");
			Console.ReadKey();
		}
	}
}